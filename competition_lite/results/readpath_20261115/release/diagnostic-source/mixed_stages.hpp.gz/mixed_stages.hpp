#pragma once
#include <chrono>
#include <cstdint>
extern "C" void mixed_stage_record(unsigned,uint64_t);
extern "C" void mixed_counter(unsigned,uint64_t);
struct MixedStage { unsigned index;std::chrono::steady_clock::time_point start;
 explicit MixedStage(unsigned i):index(i),start(std::chrono::steady_clock::now()){}
 ~MixedStage(){mixed_stage_record(index,std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count());}};
#define MIXED_EXPR(i,e) ([&](){MixedStage mixed_stage(i);return (e);}())
