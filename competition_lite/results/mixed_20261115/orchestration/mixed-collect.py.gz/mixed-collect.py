"""Archive finished experiment evidence without copying database/input payloads."""
from pathlib import Path
import collections,gzip,hashlib,json,tarfile,time

b=Path('/mnt/SSD1/zzp/seekdb-round2-lite2000/mixed-100k-300k-20261115')
assert (b/'completed.json').exists() and (b/'stages-completed.json').exists()
with tarfile.open('/tmp/zzp-mixed-orchestration.tar.gz') as tar:tar.extractall(b,filter='data')
out=b/'evidence';out.mkdir(exist_ok=False)
inventory=[]

def keep(path,relative=None):
 relative=relative or path.relative_to(b).as_posix()
 data=path.read_bytes();dest=out/(relative+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(gzip.compress(data,compresslevel=9,mtime=0))
 inventory.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gzip_bytes':dest.stat().st_size})

for path in sorted(b.glob('*.json')):keep(path)
for path in sorted(b.glob('*.log')):keep(path)
for name in ['runs','diagnostic','stages','smoke','smoke-sync','smoke-stages']:
 for path in sorted((b/name).glob('*/*')):
  if path.is_file() and path.suffix in ['.json','.log']:keep(path)
for path in sorted((b/'bench').glob('*')):
 if path.is_file() and path.suffix in ['.py','.cpp']:keep(path)
for path in sorted((b/'orchestration').glob('*.py')):keep(path)
for path in sorted((b/'instrumented').glob('*/instrumentation.json')):keep(path)

inputs={}
for rows in [200,100000,300000]:
 p=b/f'input-{rows}';meta=json.loads((p/'prepared.json').read_text());cases=json.loads((p/'cases.json').read_text());warm=json.loads((p/'warmup.json').read_text())
 requests=[json.loads(line) for line in (p/'queries.jsonl').open()]
 sqls=[r['sql'] for r in requests];vectors=[tuple(c['vector']) for c in cases+warm]
 assert len(set(sqls))==len(sqls) and len(set(vectors))==len(vectors)
 groups=collections.Counter(f'{c["dim"]}/{c["filter"]}' for c in cases)
 assert set(groups.values())=={len(cases)//4}
 item={'unique_main_sql':len(set(sqls)),'unique_main_and_warmup_vectors':len(set(vectors)),'query_groups':dict(groups),'rows_per_dimension':rows//2,'commits':rows//100,'all_run_input_hashes_match':True}
 for result in (b/'runs').glob(f'{rows}-*/result.json'):
  r=json.loads(result.read_text());assert r['prepared_sha256']==meta['sha256'],result
 for name in ['prepared.json','cases.json','queries.jsonl','warmup.json']:
  keep(p/name)
 for dim in [128,1024]:
  for name in ['cases.tsv','queries.f32','oracle.jsonl']:keep(p/str(dim)/name)
 inputs[str(rows)]=item

files={}
for result in sorted((b/'runs').glob('*/result.json')):
 files[result.parent.name]={p.relative_to(result.parent/'data').as_posix():p.stat().st_size for p in (result.parent/'data').rglob('*') if p.is_file()}
(out/'input_validation.json').write_text(json.dumps(inputs,indent=2)+'\n')
(out/'final_files.json').write_text(json.dumps(files,indent=2)+'\n')
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
with tarfile.open(b/'evidence.tar','w') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file():tar.add(p,arcname=p.relative_to(out).as_posix())
print(json.dumps({'files':len(inventory),'archive_bytes':(b/'evidence.tar').stat().st_size,'inputs':inputs}),flush=True)
