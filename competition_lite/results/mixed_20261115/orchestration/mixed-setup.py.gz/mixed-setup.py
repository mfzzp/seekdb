from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile,time
base=Path('/mnt/SSD1/zzp/seekdb-round2-lite2000/mixed-100k-300k-20261115');base.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,PATH='/home/zzp/.local/bin:'+os.environ['PATH'],DOCKER_HOST='unix:///run/user/1002/docker-competition.sock')
variants={'scored-f885':('/mnt/HDD2/zzp/minivectordb-round2','f885c285606e9c0b62806d92f29b96977e2badf8',['Dockerfile','.dockerignore','minivectordb.cpp']),
 'cpp-449':('/mnt/HDD2/zzp/seekdb-cpp-integrated','449bba12112755a1a3061a422b383587a5bb468a',['Dockerfile','.dockerignore','minivectordb.cpp','v2'])}
meta={'root':str(base),'variants':{},'disk_free_bytes':os.statvfs(base).f_bavail*os.statvfs(base).f_frsize}
assert meta['disk_free_bytes']>60*(1<<30),meta['disk_free_bytes']
for label,(repo,commit,paths) in variants.items():
 dest=base/'source'/label;dest.mkdir(parents=True)
 raw=subprocess.check_output(['git','-C',repo,'archive',commit,'--',*paths])
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(dest,filter='data')
 meta['variants'][label]={'commit':commit,'files':{p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()}}
image='lite:linear-20261115';meta['compiler_image']=json.loads(subprocess.check_output(['docker','image','inspect',image],env=env))[0]['Id']
meta['compiler']=subprocess.check_output(['docker','run','--rm','--network=none','--entrypoint','g++',image,'--version'],env=env,text=True).splitlines()[0]
meta['cpu']=subprocess.check_output(['lscpu'],text=True)
(base/'setup.json').write_text(json.dumps(meta,indent=2)+'\n')
with tarfile.open(base/'old-sources.tar.gz','w:gz') as t:
 for label in variants:t.add(base/'source'/label,arcname=label)
print(json.dumps(meta,indent=2))
