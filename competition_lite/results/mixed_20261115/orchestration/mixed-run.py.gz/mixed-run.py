from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
base=Path('/mnt/SSD1/zzp/seekdb-round2-lite2000/mixed-100k-300k-20261115')
with tarfile.open('/tmp/zzp-mixed-package.tar.gz') as t:t.extractall(base,filter='data')
env=dict(os.environ,PATH='/home/zzp/.local/bin:'+os.environ['PATH'],DOCKER_HOST='unix:///run/user/1002/docker-competition.sock')
bench=base/'bench';(base/'bin').mkdir();steps=[];variants=['new-24','scored-f885','cpp-449'];meta=json.loads((base/'setup.json').read_text());meta['variants']['new-24']=json.loads((base/'new-source.json').read_text())
def run(name,args,timeout=1800,required=True):
 start=time.monotonic()
 with (base/(name+'.log')).open('w') as log:p=subprocess.run(list(map(str,args)),env=env,cwd=base,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 item={'name':name,'returncode':p.returncode,'seconds':time.monotonic()-start};steps.append(item);(base/'progress.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(item),flush=True)
 if p.returncode:
  print((base/(name+'.log')).read_text()[-4000:],flush=True)
  if required:raise RuntimeError(item)
 return p.returncode
common='lite:linear-20261115'
for label in variants:
 image='lite:mixed-'+label+'-20261115';src=base/'source'/label
 run('build-'+label,['docker','build','-t',image,src],900)
 container=subprocess.check_output(['docker','create',image],env=env,text=True).strip()
 try:subprocess.run(['docker','cp',container+':/app/minivectordb',str(base/'bin'/label)],env=env,check=True)
 finally:subprocess.run(['docker','rm',container],env=env,check=True,stdout=subprocess.DEVNULL)
 meta['variants'][label]['binary_sha256']=hashlib.sha256((base/'bin'/label).read_bytes()).hexdigest();meta['variants'][label]['image_id']=json.loads(subprocess.check_output(['docker','inspect',image],env=env))[0]['Id']
 compiler=subprocess.check_output(['docker','run','--rm','--network=none','--entrypoint','g++',image,'--version'],env=env,text=True).splitlines()[0];assert compiler==meta['compiler'],compiler
 meta['variants'][label]['compiler']=compiler
(base/'builds.json').write_text(json.dumps(meta,indent=2)+'\n')
docker=['docker','run','--rm','--network=none','--cpus=2','--memory=2g','--memory-swap=2g','--mount',f'type=bind,src={base},dst=/work','--entrypoint','g++',common]
for name,file in [('generate','mixed_generate.cpp'),('oracle','exact_oracle.cpp')]:run('build-'+name,docker+['-O3','-DNDEBUG','-std=c++17','-Wall','-Wextra','/work/bench/'+file,'-o','/work/bin/'+name])
for label in variants:
 src='/work/source/'+label
 files=[src+'/competition_lite/src/minivectordb_lite.cpp'] if label=='new-24' else [src+'/minivectordb.cpp']+([src+'/v2/v2_storage.cpp'] if label=='cpp-449' else [])
 run('build-sync-'+label,docker+['-O3','-DNDEBUG','-std=c++17','-Wall','-Wextra',*files,'/work/bench/mixed_sync_probe.cpp','-Wl,--wrap=fsync','-Wl,--wrap=fdatasync','-o','/work/bin/sync-'+label])
def prepare(rows,queries=1000):
 p=base/('input-'+str(rows));run('generate-'+str(rows),[base/'bin/generate',rows,p]);run('prepare-'+str(rows),['python3',bench/'mixed_compare.py','prepare','--root',p,'--rows',rows,'--queries',queries])
 for d in [128,1024]:run('oracle-'+str(rows)+'-'+str(d),[base/'bin/oracle',p/f'vectors{d}.f32',p/str(d),rows//2,d,p/str(d)/'oracle.jsonl'])
 return p
smoke=prepare(200,128)
for label in variants:
 run('smoke-'+label,['python3',bench/'mixed_compare.py','run','--prepared',smoke,'--root',base/'smoke'/label,'--binary',base/'bin'/label,'--image',common,'--label',label+'-smoke'])
 run('smoke-sync-'+label,['python3',bench/'mixed_compare.py','run','--prepared',smoke,'--root',base/'smoke-sync'/label,'--binary',base/'bin'/('sync-'+label),'--image',common,'--label',label+'-sync-smoke','--diagnostic'])
for rows in [100000,300000]:
 prepared=prepare(rows)
 for round_no in range(3):
  order=variants[round_no:]+variants[:round_no]
  for label in order:
   name=f'{rows}-{label}-r{round_no+1}'
   run(name,['python3',bench/'mixed_compare.py','run','--prepared',prepared,'--root',base/'runs'/name,'--binary',base/'bin'/label,'--image',common,'--label',name],3600,False)
 for label in variants:
  name=f'{rows}-{label}-diagnostic'
  run(name,['python3',bench/'mixed_compare.py','run','--prepared',prepared,'--root',base/'diagnostic'/name,'--binary',base/'bin'/('sync-'+label),'--image',common,'--label',name,'--diagnostic'],3600,False)
(base/'completed.json').write_text(json.dumps({'completed':True,'steps':len(steps),'failed_steps':[s for s in steps if s['returncode']]},indent=2)+'\n')
