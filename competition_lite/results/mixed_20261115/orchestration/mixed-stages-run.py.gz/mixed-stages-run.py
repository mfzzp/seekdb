from pathlib import Path
import json,os,subprocess,tarfile,time
b=Path('/mnt/SSD1/zzp/seekdb-round2-lite2000/mixed-100k-300k-20261115');started=time.monotonic()
while not (b/'completed.json').exists():
 time.sleep(10)
 if time.monotonic()-started>21000:raise RuntimeError('primary experiments not complete')
with tarfile.open('/tmp/zzp-mixed-stage-tools.tar.gz') as t:t.extractall(b,filter='data')
env=dict(os.environ,PATH='/home/zzp/.local/bin:'+os.environ['PATH'],DOCKER_HOST='unix:///run/user/1002/docker-competition.sock')
image='lite:linear-20261115';bench=b/'bench';steps=[]
def run(name,args,required=True,timeout=1800):
 start=time.monotonic()
 with (b/(name+'.log')).open('w') as log:p=subprocess.run(list(map(str,args)),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 item={'name':name,'returncode':p.returncode,'seconds':time.monotonic()-start};steps.append(item);(b/'stage-progress.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(item),flush=True)
 if p.returncode:
  print((b/(name+'.log')).read_text()[-4000:])
  if required:raise RuntimeError(item)
docker=['docker','run','--rm','--network=none','--cpus=2','--memory=2g','--memory-swap=2g','--mount',f'type=bind,src={b},dst=/work','--entrypoint','g++',image]
for label in ['new-24','scored-f885','cpp-449']:
 source=b/'source'/label/('competition_lite/src/minivectordb_lite.cpp' if label=='new-24' else 'minivectordb.cpp');out=b/'instrumented'/label
 run('instrument-'+label,['python3',bench/'mixed_instrument.py','--source',source,'--out',out])
 files=['/work/instrumented/'+label+'/'+source.name]
 if label=='cpp-449':files.append('/work/instrumented/'+label+'/v2/v2_storage.cpp')
 run('build-stages-'+label,docker+['-O3','-DNDEBUG','-std=c++17','-Wall','-Wextra',*files,'/work/instrumented/'+label+'/probe.cpp','-Wl,--wrap=fsync','-Wl,--wrap=fdatasync','-o','/work/bin/stages-'+label])
 run('smoke-stages-'+label,['python3',bench/'mixed_stage_run.py','run','--prepared',b/'input-200','--root',b/'smoke-stages'/label,'--binary',b/'bin'/('stages-'+label),'--image',image,'--label',label+'-stages-smoke','--diagnostic'])
for rows in [100000,300000]:
 for label in ['new-24','scored-f885','cpp-449']:
  name=f'{rows}-{label}-stages'
  run(name,['python3',bench/'mixed_stage_run.py','run','--prepared',b/('input-'+str(rows)),'--root',b/'stages'/name,'--binary',b/'bin'/('stages-'+label),'--image',image,'--label',name,'--diagnostic'],False,3600)
(b/'stages-completed.json').write_text(json.dumps({'complete':True,'failed':[s for s in steps if s['returncode']]},indent=2)+'\n')
